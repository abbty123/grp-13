class Country:
    # This class holds the details of one country

    def __init__(self, name, capital, currencies, languages, population, region, flag_url, timezones):
        self.name = name
        self.capital = capital
        self.currencies = currencies
        self.languages = languages
        self.population = population
        self.region = region
        self.flag_url = flag_url
        self.timezones = timezones

    @classmethod
    def from_api_data(cls, data):
        # This takes the raw data from the API and turns it into a Country object
        name = data.get("name", {}).get("common", "Unknown")

        capital_list = data.get("capital", [])
        if len(capital_list) > 0:
            capital = capital_list[0]
        else:
            capital = "N/A"

        currencies_data = data.get("currencies", {})
        currencies = []
        for code in currencies_data:
            info = currencies_data[code]
            currency_name = info.get("name", code)
            currency_symbol = info.get("symbol", "")
            currencies.append(currency_name + " (" + currency_symbol + ")")
        if len(currencies) == 0:
            currencies = ["N/A"]

        languages_data = data.get("languages", {})
        languages = list(languages_data.values())
        if len(languages) == 0:
            languages = ["N/A"]

        population = data.get("population", 0)
        region = data.get("region", "N/A")
        flag_url = data.get("flags", {}).get("png", "")
        timezones = data.get("timezones", ["N/A"])

        return cls(name, capital, currencies, languages, population, region, flag_url, timezones)

    def to_dict(self):
        # Turns the Country object into a dictionary so it can be saved to a JSON file
        return {
            "name": self.name,
            "capital": self.capital,
            "currencies": self.currencies,
            "languages": self.languages,
            "population": self.population,
            "region": self.region,
            "flag_url": self.flag_url,
            "timezones": self.timezones,
        }

    def display(self):
        # Prints out the country details in a readable way
        print("Country:", self.name)
        print("Capital:", self.capital)
        print("Region:", self.region)
        print("Population:", self.population)
        print("Currencies:", ", ".join(self.currencies))
        print("Languages:", ", ".join(self.languages))
        print("Timezones:", ", ".join(self.timezones))
