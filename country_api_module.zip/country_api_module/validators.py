import re


def is_valid_country_name(name):
    # A country name should only have letters, spaces, apostrophes, dots, and dashes
    if name is None:
        return False
    name = name.strip()
    if name == "":
        return False
    pattern = r"^[A-Za-z\s.'-]+$"
    if re.match(pattern, name):
        return True
    return False


def is_valid_country_code(code):
    # A valid country code is 2 or 3 letters, like NG or NGA
    if code is None:
        return False
    code = code.strip()
    pattern = r"^[A-Za-z]{2,3}$"
    if re.match(pattern, code):
        return True
    return False
