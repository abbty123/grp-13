import requests

from country import Country
from validators import is_valid_country_name, is_valid_country_code


class CountryAPIClient:
    # This class talks to the REST Countries API

    def __init__(self):
        self.base_url = "https://restcountries.com/v3.1"
        self.fields = "name,capital,currencies,languages,population,region,flags,timezones"

    def search_by_name(self, name):
        # Search for a country using its name, e.g "Nigeria"
        if not is_valid_country_name(name):
            raise ValueError(name + " is not a valid country name.")

        url = self.base_url + "/name/" + name
        data = self.get_data(url)

        # the API gives back a list of matches, we just take the first one
        return Country.from_api_data(data[0])

    def search_by_code(self, code):
        # Search for a country using its code, e.g "NG" or "NGA"
        if not is_valid_country_code(code):
            raise ValueError(code + " is not a valid country code.")

        url = self.base_url + "/alpha/" + code
        data = self.get_data(url)

        if isinstance(data, list):
            data = data[0]
        return Country.from_api_data(data)

    def get_data(self, url):
        # Sends the request to the API and deals with errors
        try:
            response = requests.get(url, params={"fields": self.fields}, timeout=10)
            response.raise_for_status()
            data = response.json()

            if not data:
                raise Exception("No data found for that country.")

            return data

        except requests.exceptions.Timeout:
            raise Exception("Request timed out. Check your internet connection.")
        except requests.exceptions.ConnectionError:
            raise Exception("Could not connect to the API. Check your internet connection.")
        except requests.exceptions.HTTPError:
            raise Exception("Country not found. Check the spelling and try again.")


if __name__ == "__main__":
    client = CountryAPIClient()
    try:
        country = client.search_by_name("Nigeria")
        country.display()
    except Exception as e:
        print("Error:", e)
